# X-Ray Forensic — Compliance Rules (NON-NEGOTIABLE)

These rules override everything. If a piece of content violates any rule below, it does NOT ship — no exceptions, no matter how good the marketing angle.

## The absolute rules

### 1. Demo results must be labeled
Any performance figure, leak amount, or result derived from a demo/test account MUST be explicitly labeled "demo account" or "example." The founder's $4,753 figure is from a DEMONSTRATION account — always state this.
- ✅ "Found $4,753 in leaks on a demo account."
- ❌ "Found $4,753 in leaks." (implies real money)

### 2. Never guarantee results
X-Ray never promises profits, specific outcomes, or guaranteed improvement.
- ✅ "Identifies what's costing you money."
- ❌ "Will make you profitable." / "Guaranteed to improve your win rate."

### 3. Always include risk language where appropriate
Marketing that discusses results or performance must carry or be near: "Not financial advice. Trading involves risk." For short-form (tweets, etc.) where it doesn't fit naturally, the linked landing page carries it.

### 4. X-Ray is analytics, not advice or execution
- X-Ray is a diagnostic/analytics tool.
- X-Ray is NOT financial advice.
- X-Ray is NOT a broker and does NOT execute trades.
- X-Ray is NOT a signal service.
Never imply otherwise.

### 5. No fake social proof
- No invented testimonials.
- No made-up user counts ("join 10,000 traders" when it's not true).
- No fabricated statistics. Research real ones or label as illustrative/industry-typical.

### 6. Individual results vary
Any time outcomes are discussed: "Individual results vary." Trading outcomes depend on the trader, not the tool.

## Required disclaimer text (use verbatim where space allows)
"X-Ray Forensic is an analytics tool, not financial advice. Trading involves substantial risk of loss. Past performance and example results do not guarantee future outcomes. Individual results vary."

Short version (for tight spaces):
"Not financial advice. Trading involves risk."

## Self-check before presenting any content
Run this checklist on every draft:
- [ ] Any result figure labeled demo/example?
- [ ] No profit guarantees?
- [ ] No implication X-Ray executes trades or gives advice?
- [ ] Risk language present or on the linked page?
- [ ] No fake testimonials or invented numbers?
- [ ] Honest about current product state (rule-based reports, crypto payment, early stage)?

If any box fails → fix before presenting. If unsure → flag it to the operator, don't ship it.

## Why this matters
Trading-related products attract regulatory scrutiny. Implying guaranteed returns or presenting demo results as real performance can create legal liability and destroy trust. The brand's entire premise is "the data doesn't lie" — non-compliant marketing would contradict the core promise.
