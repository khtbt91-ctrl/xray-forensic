# X-Ray Forensic — Brand Voice

## The core identity
Clinical. Forensic. Institutional. Bloomberg Terminal meets prop desk risk system. We are a forensic intelligence system, not a trading guru, not a hype channel, not a signal service.

## The feeling every piece should create
"This is serious. This knows something I don't. This isn't trying to sell me a dream — it's showing me the truth about my trading."

## Tone rules

### DO
- State facts with specificity: "Your 276 revenge trades cost you $16.86 net at 29.1% win rate."
- Use precise numbers, sessions, dollar figures
- Speak with quiet authority — the confidence of data, not the loudness of a salesman
- Be direct and unsentimental
- Treat the reader as a serious professional, even when they're a beginner
- Use institutional/forensic vocabulary: diagnosis, verdict, leak, evidence, forensic, prescription, protocol, the desk

### DON'T
- No motivational padding: ❌ "Try to control your emotions and wait for better setups!"
- No hype: ❌ "🚀 10x your trading!" ❌ "Secret strategy the pros don't want you to know!"
- No get-rich-quick energy of any kind
- No fake urgency: ❌ "Only 24 hours left!"
- No emojis as hype devices (occasional functional use is fine, e.g. 🔴 for a high-impact event)
- No exclamation marks as enthusiasm crutches
- No empty superlatives: "amazing," "incredible," "game-changing"

## Voice examples

### Good (clinical, specific, true)
- "The data shows a trader who enters on emotion and exits on fear. 67% of trades were taken outside any institutional session window. That is the primary source of loss."
- "You win 54% of trades and still lose money. Your average loser is twice your average winner. The math was never going to work."
- "Built by a trader who ran his own demo account through X-Ray and found $4,753 in stop-loss leaks. The data doesn't lie."

### Bad (hype, vague, salesy)
- "Transform your trading and unlock your true potential!"
- "Join thousands of winning traders today!"
- "The ultimate game-changing tool that will revolutionize how you trade!"

## Headline patterns that work
- "Why you lose — not just that you lost."
- "Your trades leave evidence."
- "The market was doing something to you. Here's what."
- "[Number] [specific behavior] cost you [dollar amount]."

## The founder voice
A 15-year institutional trader. Speaks from experience, not theory. Slightly weary of retail trading myths. Believes in data over feelings. Quietly confident. Never desperate. Example: "I ran my own demo account through this and found leaks I'd been bleeding for years without seeing. That's why I built it."

## Audience calibration
- To beginners: respectful, never condescending. "Day one" not "noob." Teach without talking down.
- To prop traders: precise, results-focused, they know the terms.
- To skeptics: let the data and specificity do the convincing. Don't oversell.

## The litmus test
Before publishing any line, ask: "Would a serious institutional trader respect this, or would they roll their eyes?" If they'd roll their eyes, rewrite it.
